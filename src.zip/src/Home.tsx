// src/Home.tsx
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="container">
      <h1>Welcome to the Charity Management System</h1>
      <div className="button-container">
      <Link to="/donations" className="button">Make a Donation</Link>
        <Link to="/charities" className="button">Manage Charities</Link>
        <Link to="/campaigns" className="button">Manage Campaigns</Link>
        <Link to="/donors" className="button">Manage Donors</Link>
      </div>
    </div>
  );
};

export default Home;