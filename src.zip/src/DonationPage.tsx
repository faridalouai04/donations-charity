import React, { useState, useEffect } from "react";
import axios from "axios";
import './App.css'; // Assuming this is the external CSS file

const Donations: React.FC = () => {
  const [donations, setDonations] = useState([]);
  const [form, setForm] = useState({
    donorId: "",
    campaignId: "",
    amount: "",
  });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    fetchDonations();
  }, []);

  const fetchDonations = async () => {
    try {
      const response = await axios.get("http://localhost:5001/api/donations");
      setDonations(response.data);
    } catch (error) {
      console.error("Error fetching donations:", error);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const validateForm = () => {
    let formErrors: { [key: string]: string } = {};
    let isValid = true;

    if (!form.donorId) {
      formErrors.donorId = "Donor ID is required";
      isValid = false;
    }
    if (!form.campaignId) {
      formErrors.campaignId = "Campaign ID is required";
      isValid = false;
    }
    if (!form.amount || isNaN(Number(form.amount))) {
      formErrors.amount = "Amount must be a valid number";
      isValid = false;
    }

    setErrors(formErrors);
    return isValid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      if (editingId) {
        await axios.put(`http://localhost:5001/api/donations/${editingId}`, form);
        setEditingId(null);
      } else {
        await axios.post("http://localhost:5001/api/donations", form);
      }

      fetchDonations();

      setForm({
        donorId: "",
        campaignId: "",
        amount: "",
      });
      setErrors({});
    } catch (error) {
      console.error("Error saving donation:", error);
    }
  };

  const handleEdit = (donation: any) => {
    setEditingId(donation.id);
    setForm({
      donorId: donation.donor_id,
      campaignId: donation.campaign_id,
      amount: donation.amount,
    });
  };

  const handleDelete = async (id: number) => {
    try {
      await axios.delete(`http://localhost:5001/api/donations/${id}`);
      fetchDonations();
    } catch (error) {
      console.error("Error deleting donation:", error);
    }
  };

  return (
    <div className="container">
      <h1>Donations</h1>
      <form onSubmit={handleSubmit} className="form">
        <input
          name="donorId"
          placeholder="Donor ID"
          value={form.donorId}
          onChange={handleChange}
          required
          className="input"
        />
        <input
          name="campaignId"
          placeholder="Campaign ID"
          value={form.campaignId}
          onChange={handleChange}
          required
          className="input"
        />
        <input
          name="amount"
          placeholder="Amount"
          value={form.amount}
          onChange={handleChange}
          required
          className="input"
        />
        {errors.amount && <p className="error">{errors.amount}</p>}

        <button type="submit" className="btn">{editingId ? "Update Donation" : "Add Donation"}</button>
      </form>

      <table className="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Donor ID</th>
            <th>Campaign ID</th>
            <th>Amount</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {donations.map((donation: any) => (
            <tr key={donation.id}>
              <td>{donation.id}</td>
              <td>{donation.donor_id}</td>
              <td>{donation.campaign_id}</td>
              <td>{donation.amount}</td>
              <td>
                <button onClick={() => handleEdit(donation)} className="btn-edit">Edit</button>
                <button onClick={() => handleDelete(donation.id)} className="btn-delete">Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Donations;
