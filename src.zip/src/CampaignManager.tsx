import React, { useState, useEffect } from "react";
import axios from "axios";
import './App.css'; // Assuming this is the external CSS file

const Campaigns: React.FC = () => {
  const [campaigns, setCampaigns] = useState([]);
  const [form, setForm] = useState({
    title: "",
    description: "",
    goalAmount: "",
    preferredCurrency: "USD", // default to USD
    startDate: "",
    endDate: "",
    charityId: "",
  });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    fetchCampaigns();
  }, []);

  const fetchCampaigns = async () => {
    try {
      const response = await axios.get("http://localhost:5001/api/campaigns");
      setCampaigns(response.data);
    } catch (error) {
      console.error("Error fetching campaigns:", error);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const validateForm = () => {
    let formErrors: { [key: string]: string } = {};
    let isValid = true;

    if (!form.title) {
      formErrors.title = "Title is required";
      isValid = false;
    }
    if (!form.description) {
      formErrors.description = "Description is required";
      isValid = false;
    }

    // Goal amount must be a valid number
    if (!form.goalAmount || isNaN(Number(form.goalAmount))) {
      formErrors.goalAmount = "Goal amount must be a valid number";
      isValid = false;
    }

    // Preferred currency should be in the allowed list
    const allowedCurrencies = ["USD", "EGP", "EUR"];
    if (!allowedCurrencies.includes(form.preferredCurrency)) {
      formErrors.preferredCurrency = "Preferred currency must be USD, EGP, or EUR";
      isValid = false;
    }

    // Start date validation: Must be at least today
    const today = new Date().toISOString().split("T")[0];
    if (form.startDate < today) {
      formErrors.startDate = "Start date must be today or later";
      isValid = false;
    }

    // End date validation: Must be after start date
    if (form.endDate <= form.startDate) {
      formErrors.endDate = "End date must be after the start date";
      isValid = false;
    }

    setErrors(formErrors);
    return isValid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate form before submitting
    if (!validateForm()) {
      return;
    }

    try {
      if (editingId) {
        // Update existing campaign
        await axios.put(`http://localhost:5001/api/campaigns/${editingId}`, form);
        setEditingId(null);
      } else {
        // Add new campaign
        await axios.post("http://localhost:5001/api/campaigns", form);
      }

      // Auto-refresh the campaigns after adding or updating
      fetchCampaigns();

      // Reset form and errors
      setForm({
        title: "",
        description: "",
        goalAmount: "",
        preferredCurrency: "USD",
        startDate: "",
        endDate: "",
        charityId: "",
      });
      setErrors({});
    } catch (error) {
      console.error("Error saving campaign:", error);
    }
  };

  const handleEdit = (campaign: any) => {
    setEditingId(campaign.id);
    setForm({
      title: campaign.title,
      description: campaign.description,
      goalAmount: campaign.goal_amount,
      preferredCurrency: campaign.preferred_currency,
      startDate: campaign.start_date,
      endDate: campaign.end_date,
      charityId: campaign.charity_id,
    });
  };

  const handleDelete = async (id: number) => {
    try {
      await axios.delete(`http://localhost:5001/api/campaigns/${id}`);
      fetchCampaigns();
    } catch (error) {
      console.error("Error deleting campaign:", error);
    }
  };

  return (
    <div className="container">
      <h1>Campaigns</h1>
      <form onSubmit={handleSubmit} className="form">
        <input
          name="title"
          placeholder="Title"
          value={form.title}
          onChange={handleChange}
          required
          className="input"
        />
        <textarea
          name="description"
          placeholder="Description"
          value={form.description}
          onChange={handleChange}
          required
          className="input"
        />
        <input
          name="goalAmount"
          placeholder="Goal Amount"
          value={form.goalAmount}
          onChange={handleChange}
          required
          className="input"
        />
        {errors.goalAmount && <p className="error">{errors.goalAmount}</p>}

        <select
          name="preferredCurrency"
          value={form.preferredCurrency}
          onChange={handleChange}
          required
          className="input"
        >
          <option value="USD">USD</option>
          <option value="EGP">EGP</option>
          <option value="EUR">EUR</option>
        </select>
        {errors.preferredCurrency && <p className="error">{errors.preferredCurrency}</p>}

        <input
          type="date"
          name="startDate"
          value={form.startDate}
          onChange={handleChange}
          required
          className="input"
        />
        {errors.startDate && <p className="error">{errors.startDate}</p>}

        <input
          type="date"
          name="endDate"
          value={form.endDate}
          onChange={handleChange}
          required
          className="input"
        />
        {errors.endDate && <p className="error">{errors.endDate}</p>}

        <input
          name="charityId"
          placeholder="Charity ID"
          value={form.charityId}
          onChange={handleChange}
          required
          className="input"
        />

        <button type="submit" className="btn">{editingId ? "Update Campaign" : "Add Campaign"}</button>
      </form>

      <table className="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Description</th>
            <th>Goal Amount</th>
            <th>Preferred Currency</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Charity ID</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {campaigns.map((campaign: any) => (
            <tr key={campaign.id}>
              <td>{campaign.id}</td>
              <td>{campaign.title}</td>
              <td>{campaign.description}</td>
              <td>{campaign.goal_amount}</td>
              <td>{campaign.preferred_currency}</td>
              <td>{campaign.start_date}</td>
              <td>{campaign.end_date}</td>
              <td>{campaign.charity_id}</td>
              <td>
                <button onClick={() => handleEdit(campaign)} className="btn-edit">Edit</button>
                <button onClick={() => handleDelete(campaign.id)} className="btn-delete">Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Campaigns;