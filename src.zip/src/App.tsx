// src/App.tsx
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './Home';
import Charities from './CharityManager';
import Campaigns from './CampaignManager';
import Donors from './DonorManager';
import Donations from './DonationPage'; // Import the new page
import './styles.css';

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/charities" element={<Charities />} />
        <Route path="/campaigns" element={<Campaigns />} />
        <Route path="/donors" element={<Donors />} />
        <Route path="/donations" element={<Donations />} />
      </Routes>
    </Router>
  );
};

export default App;