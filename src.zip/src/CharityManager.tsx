import React, { useState, useEffect } from "react";
import axios from "axios";
import './App.css'; // Assuming this is the external CSS file

const charities: React.FC = () => {
  const [charities, setCharities] = useState([]);
  const [form, setForm] = useState({
    name: "",
    description: "",
    location: "",
    websiteUrl: "",
    contactInfo: "",
    identificationDocument: null, // For file uploads
    documentStatus: "Pending", // default value
  });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    fetchCharities();
  }, []);

  const fetchCharities = async () => {
    try {
      const response = await axios.get("http://localhost:5001/api/charities");
      setCharities(response.data);
    } catch (error) {
      console.error("Error fetching charities:", error);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, identificationDocument: e.target.files ? e.target.files[0] : null });
  };

  const validateForm = () => {
    let formErrors: { [key: string]: string } = {};
    let isValid = true;

    if (!form.name) {
      formErrors.name = "Name is required";
      isValid = false;
    }
    if (!form.description) {
      formErrors.description = "Description is required";
      isValid = false;
    }

    setErrors(formErrors);
    return isValid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      const formData = new FormData();
      Object.keys(form).forEach(key => formData.append(key, form[key as keyof typeof form]));
      
      if (editingId) {
        await axios.put(`http://localhost:5001/api/charities/${editingId}`, formData);
        setEditingId(null);
      } else {
        await axios.post("http://localhost:5001/api/charities", formData);
      }

      fetchCharities();

      setForm({
        name: "",
        description: "",
        location: "",
        websiteUrl: "",
        contactInfo: "",
        identificationDocument: null,
        documentStatus: "Pending",
      });
      setErrors({});
    } catch (error) {
      console.error("Error saving charity:", error);
    }
  };

  const handleEdit = (charity: any) => {
    setEditingId(charity.id);
    setForm({
      name: charity.name,
      description: charity.description,
      location: charity.location,
      websiteUrl: charity.website_url,
      contactInfo: charity.contact_info,
      identificationDocument: null,
      documentStatus: charity.document_status,
    });
  };

  const handleDelete = async (id: number) => {
    try {
      await axios.delete(`http://localhost:5001/api/charities/${id}`);
      fetchCharities();
    } catch (error) {
      console.error("Error deleting charity:", error);
    }
  };

  return (
    <div className="container">
      <h1>Charities</h1>
      <form onSubmit={handleSubmit} className="form">
        <input
          name="name"
          placeholder="Name"
          value={form.name}
          onChange={handleChange}
          required
          className="input"
        />
        <textarea
          name="description"
          placeholder="Description"
          value={form.description}
          onChange={handleChange}
          required
          className="input"
        />
        <input
          name="location"
          placeholder="Location"
          value={form.location}
          onChange={handleChange}
          className="input"
        />
        <input
          name="websiteUrl"
          placeholder="Website URL"
          value={form.websiteUrl}
          onChange={handleChange}
          className="input"
        />
        <textarea
          name="contactInfo"
          placeholder="Contact Info"
          value={form.contactInfo}
          onChange={handleChange}
          className="input"
        />
        <input
          type="file"
          name="identificationDocument"
          onChange={handleFileChange}
          className="input"
        />
        <select
          name="documentStatus"
          value={form.documentStatus}
          onChange={handleChange}
          className="input"
        >
          <option value="Pending">Pending</option>
          <option value="Approved">Approved</option>
          <option value="Rejected">Rejected</option>
        </select>

        <button type="submit" className="btn">{editingId ? "Update Charity" : "Add Charity"}</button>
      </form>

      <table className="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Location</th>
            <th>Website URL</th>
            <th>Contact Info</th>
            <th>Document Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {charities.map((charity: any) => (
            <tr key={charity.id}>
              <td>{charity.id}</td>
              <td>{charity.name}</td>
              <td>{charity.description}</td>
              <td>{charity.location}</td>
              <td>{charity.website_url}</td>
              <td>{charity.contact_info}</td>
              <td>{charity.document_status}</td>
              <td>
                <button onClick={() => handleEdit(charity)} className="btn-edit">Edit</button>
                <button onClick={() => handleDelete(charity.id)} className="btn-delete">Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default charities;
