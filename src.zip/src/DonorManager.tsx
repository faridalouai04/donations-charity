import React, { useState, useEffect } from "react";
import axios from "axios";
import './App.css'; // Assuming this is the external CSS file

const Donors: React.FC = () => {
  const [donors, setDonors] = useState([]);
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phoneNumber: "",
    preferredLanguage: "English", // Default language is English
    address: "",
  });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    fetchDonors();
  }, []);

  const fetchDonors = async () => {
    try {
      const response = await axios.get("http://localhost:5001/api/donors");
      setDonors(response.data);
    } catch (error) {
      console.error("Error fetching donors:", error);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const validateForm = () => {
    let formErrors: { [key: string]: string } = {};
    let isValid = true;

    if (!form.firstName) {
      formErrors.firstName = "First name is required";
      isValid = false;
    }
    if (!form.lastName) {
      formErrors.lastName = "Last name is required";
      isValid = false;
    }
    if (!form.email || !/\S+@\S+\.\S+/.test(form.email)) {
      formErrors.email = "Valid email is required";
      isValid = false;
    }

    // Validate phone number
    const phoneNumberRegex = /^201\d{9}$/;
    if (!form.phoneNumber || !phoneNumberRegex.test(form.phoneNumber)) {
      formErrors.phoneNumber = "Phone number must be 12 digits and start with 201";
      isValid = false;
    }

    // Validate preferred language (only three options allowed)
    const validLanguages = ['English', 'Arabic', 'French'];
    if (!validLanguages.includes(form.preferredLanguage)) {
      formErrors.preferredLanguage = "Preferred language must be either English, Arabic, or French";
      isValid = false;
    }

    setErrors(formErrors);
    return isValid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      if (editingId) {
        await axios.put(`http://localhost:5001/api/donors/${editingId}`, form);
        setEditingId(null);
      } else {
        await axios.post("http://localhost:5001/api/donors", form);
      }

      // Refresh the donor list after adding or updating
      fetchDonors();

      // Reset the form after submit
      setForm({
        firstName: "",
        lastName: "",
        email: "",
        phoneNumber: "",
        preferredLanguage: "English", // Reset to default
        address: "",
      });
      setErrors({});
    } catch (error) {
      console.error("Error saving donor:", error);
    }
  };

  const handleEdit = (donor: any) => {
    setEditingId(donor.id);
    setForm({
      firstName: donor.first_name,
      lastName: donor.last_name,
      email: donor.email,
      phoneNumber: donor.phone_number,
      preferredLanguage: donor.preferred_language,
      address: donor.address,
    });
  };

  const handleDelete = async (id: number) => {
    try {
        // Sending DELETE request to the backend
        await axios.delete(`http://localhost:5001/api/donors/${id}`);
        
        // Refresh the donor list after deletion
        fetchDonors();
    } catch (error) {
        console.error("Error deleting donor:", error);
    }
};


  return (
    <div className="container">
      <h1>Donors</h1>
      <form onSubmit={handleSubmit} className="form">
        <input
          name="firstName"
          placeholder="First Name"
          value={form.firstName}
          onChange={handleChange}
          required
          className="input"
        />
        <input
          name="lastName"
          placeholder="Last Name"
          value={form.lastName}
          onChange={handleChange}
          required
          className="input"
        />
        <input
          name="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
          required
          className="input"
        />
        {errors.email && <p className="error">{errors.email}</p>}

        <input
          name="phoneNumber"
          placeholder="Phone Number (12 digits starting with 201)"
          value={form.phoneNumber}
          onChange={handleChange}
          className="input"
        />
        {errors.phoneNumber && <p className="error">{errors.phoneNumber}</p>}

        <select
          name="preferredLanguage"
          value={form.preferredLanguage}
          onChange={handleChange}
          className="input"
        >
          <option value="English">English</option>
          <option value="Arabic">Arabic</option>
          <option value="French">French</option>
        </select>
        {errors.preferredLanguage && <p className="error">{errors.preferredLanguage}</p>}

        <textarea
          name="address"
          placeholder="Address"
          value={form.address}
          onChange={handleChange}
          className="input"
        />

        <button type="submit" className="btn">{editingId ? "Update Donor" : "Add Donor"}</button>
      </form>

      <table className="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>Preferred Language</th>
            <th>Address</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {donors.map((donor: any) => (
            <tr key={donor.id}>
              <td>{donor.id}</td>
              <td>{donor.first_name}</td>
              <td>{donor.last_name}</td>
              <td>{donor.email}</td>
              <td>{donor.phone_number}</td>
              <td>{donor.preferred_language}</td>
              <td>{donor.address}</td>
              <td>
                <button onClick={() => handleEdit(donor)} className="btn-edit">Edit</button>
                <button onClick={() => handleDelete(donor.id)} className="btn-delete">Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Donors;